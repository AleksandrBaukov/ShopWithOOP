-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Янв 26 2021 г., 18:43
-- Версия сервера: 10.3.13-MariaDB
-- Версия PHP: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `online_store`
--

-- --------------------------------------------------------

--
-- Структура таблицы `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `id_good` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `user` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `cart`
--

INSERT INTO `cart` (`id`, `id_good`, `quantity`, `user`) VALUES
(202, 2, 8, 'new user'),
(203, 3, 7, 'new user'),
(204, 4, 1, 'new user'),
(205, 5, 1, 'new user'),
(206, 6, 2, 'new user');

-- --------------------------------------------------------

--
-- Структура таблицы `clients`
--

CREATE TABLE `clients` (
  `idClient` int(11) NOT NULL,
  `user` varchar(50) NOT NULL,
  `fio` varchar(65) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` tinytext NOT NULL,
  `pay` varchar(5) NOT NULL,
  `delivery` varchar(10) NOT NULL,
  `comment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Дамп данных таблицы `clients`
--

INSERT INTO `clients` (`idClient`, `user`, `fio`, `phone`, `email`, `address`, `pay`, `delivery`, `comment`) VALUES
(30, 'admin', 'Alex', '89175368001', 'alex03091993@gmail.com', 'Проспект 60-летия Октября 12\r\n19', 'Cash', 'Pickup', 'fghk'),
(31, 'test', 'asdg', '12351234', 'testmail@mail.ru', 'test', 'Cash', 'Pickup', 'test');

-- --------------------------------------------------------

--
-- Структура таблицы `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `fio` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `comments`
--

INSERT INTO `comments` (`id`, `fio`, `email`, `text`) VALUES
(1, 'Alex', 'mail@mail.ru', 'test text'),
(2, 'Alexandr', 'testmail@mail.ru', 'test test test');

-- --------------------------------------------------------

--
-- Структура таблицы `goods`
--

CREATE TABLE `goods` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `price` int(11) NOT NULL,
  `path` varchar(50) NOT NULL,
  `smallDesc` tinytext NOT NULL,
  `fullDesc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `goods`
--

INSERT INTO `goods` (`id`, `name`, `price`, `path`, `smallDesc`, `fullDesc`) VALUES
(1, 'Asus Predator', 5000, 'public/img/asusPredator.jpg', 'Краткое описание Asus Predator', 'Подробное описание Asus Predator'),
(2, 'Asus VivoBook', 500, 'public/img/asusVivoBook.jpg', 'Краткое описание Asus VivoBook', 'Подробное описание Asus VivoBook'),
(3, 'Iphone 11', 1000, 'public/img/iphone11.jpg', 'Краткое описание Iphone 11', 'Подробное описание Iphone 11'),
(4, 'Iphone 11 Pro', 1500, 'public/img/iphone11pro.jpeg', 'Краткое описание Iphone 11 Pro', 'Подробное описание Iphone 11 Pro'),
(5, 'MacBook Pro', 4000, 'public/img/macbookPro.jpg', 'Краткое описание MacBook Pro', 'Подробное описание MacBook Pro'),
(6, 'OnePlus 7T', 600, 'public/img/oneplus7t.jpg', 'Краткое описание OnePlus 7T', 'Подробное описание OnePlus 7T'),
(7, 'OnePlus 7T Pro', 800, 'public/img/oneplus7tPro.jpg', 'Краткое описание OnePlus 7T Pro', 'Подробное описание OnePlus 7T Pro'),
(8, 'MacBook Air', 1700, 'public/img/macbookAir.jpg', 'Краткое описание MacBook Air', 'Подробное описание MacBook Air');

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `clientFio` varchar(50) NOT NULL,
  `idGoods` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `clientFio`, `idGoods`, `quantity`, `time`) VALUES
(145, 'Alex', 4, 1, '2020-06-22 20:19:06'),
(146, 'Alex', 5, 2, '2020-06-22 20:19:06'),
(147, 'Alex', 6, 2, '2020-06-22 20:19:06'),
(148, 'Alex', 1, 1, '2020-06-22 20:19:06'),
(149, 'asdg', 4, 1, '2020-06-22 20:27:13'),
(150, 'asdg', 5, 1, '2020-06-22 20:27:13'),
(151, 'asdg', 6, 1, '2020-06-22 20:27:13'),
(152, 'asdg', 7, 1, '2020-06-22 20:27:13'),
(153, 'asdg', 8, 1, '2020-06-22 20:27:13');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `login` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pass` varchar(128) NOT NULL,
  `admin` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `email`, `pass`, `admin`) VALUES
(2, 'admin', 'admin@mail.ru', '21232f297a57a5a743894a0e4a801fc3', 1),
(3, 'test', 'testmail@mail.ru', '202cb962ac59075b964b07152d234b70', 0),
(13, '123', '123@123.ry', '07b432d25170b469b57095ca269bc202d41d8cd98f00b204e9800998ecf8427e', 0);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`idClient`);

--
-- Индексы таблицы `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `goods`
--
ALTER TABLE `goods`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=207;

--
-- AUTO_INCREMENT для таблицы `clients`
--
ALTER TABLE `clients`
  MODIFY `idClient` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT для таблицы `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `goods`
--
ALTER TABLE `goods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=155;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
